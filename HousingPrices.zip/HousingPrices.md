```python
import pandas as pd
import statsmodels.api as sm
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn import preprocessing
```

## Data Exploration 


```python
dataset = pd.read_csv("Housing.csv")

```


```python
dataset.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>price</th>
      <th>area</th>
      <th>bedrooms</th>
      <th>bathrooms</th>
      <th>stories</th>
      <th>mainroad</th>
      <th>guestroom</th>
      <th>basement</th>
      <th>hotwaterheating</th>
      <th>airconditioning</th>
      <th>parking</th>
      <th>prefarea</th>
      <th>furnishingstatus</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>13300000</td>
      <td>7420</td>
      <td>4</td>
      <td>2</td>
      <td>3</td>
      <td>yes</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>yes</td>
      <td>2</td>
      <td>yes</td>
      <td>furnished</td>
    </tr>
    <tr>
      <th>1</th>
      <td>12250000</td>
      <td>8960</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>yes</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>yes</td>
      <td>3</td>
      <td>no</td>
      <td>furnished</td>
    </tr>
    <tr>
      <th>2</th>
      <td>12250000</td>
      <td>9960</td>
      <td>3</td>
      <td>2</td>
      <td>2</td>
      <td>yes</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>no</td>
      <td>2</td>
      <td>yes</td>
      <td>semi-furnished</td>
    </tr>
  </tbody>
</table>
</div>




```python
## Swapping price and furnishingStatus columns 
colList = list(dataset.columns)
colList[0], colList[-1] =  colList[-1], colList[0]
dataset = dataset[colList]
```


```python
dataset.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>furnishingstatus</th>
      <th>area</th>
      <th>bedrooms</th>
      <th>bathrooms</th>
      <th>stories</th>
      <th>mainroad</th>
      <th>guestroom</th>
      <th>basement</th>
      <th>hotwaterheating</th>
      <th>airconditioning</th>
      <th>parking</th>
      <th>prefarea</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>furnished</td>
      <td>7420</td>
      <td>4</td>
      <td>2</td>
      <td>3</td>
      <td>yes</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>yes</td>
      <td>2</td>
      <td>yes</td>
      <td>13300000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>furnished</td>
      <td>8960</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>yes</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>yes</td>
      <td>3</td>
      <td>no</td>
      <td>12250000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>semi-furnished</td>
      <td>9960</td>
      <td>3</td>
      <td>2</td>
      <td>2</td>
      <td>yes</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>no</td>
      <td>2</td>
      <td>yes</td>
      <td>12250000</td>
    </tr>
  </tbody>
</table>
</div>




```python
dataset.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 545 entries, 0 to 544
    Data columns (total 13 columns):
     #   Column            Non-Null Count  Dtype 
    ---  ------            --------------  ----- 
     0   furnishingstatus  545 non-null    object
     1   area              545 non-null    int64 
     2   bedrooms          545 non-null    int64 
     3   bathrooms         545 non-null    int64 
     4   stories           545 non-null    int64 
     5   mainroad          545 non-null    object
     6   guestroom         545 non-null    object
     7   basement          545 non-null    object
     8   hotwaterheating   545 non-null    object
     9   airconditioning   545 non-null    object
     10  parking           545 non-null    int64 
     11  prefarea          545 non-null    object
     12  price             545 non-null    int64 
    dtypes: int64(6), object(7)
    memory usage: 55.5+ KB



```python
dataset.furnishingstatus.nunique()
```




    3




```python
dataset.furnishingstatus.value_counts()
```




    semi-furnished    227
    unfurnished       178
    furnished         140
    Name: furnishingstatus, dtype: int64




```python
dataset.parking.nunique()
```




    4




```python
dataset.columns.tolist()
```




    ['furnishingstatus',
     'area',
     'bedrooms',
     'bathrooms',
     'stories',
     'mainroad',
     'guestroom',
     'basement',
     'hotwaterheating',
     'airconditioning',
     'parking',
     'prefarea',
     'price']




```python
for column in dataset.columns.tolist():
    if column == 'price':
        continue
    if column == "area":
        plt.scatter(dataset[column], dataset['price'])
        plt.title(column)
        plt.xlabel(column)
        plt.ylabel('price')
        plt.show()
    else:
        plt.bar(dataset[column], dataset['price'])    
        plt.title(column)
        plt.xlabel(column)
        plt.ylabel('price')
        plt.tight_layout()
        plt.show()
```


    
![png](output_11_0.png)
    



    
![png](output_11_1.png)
    



    
![png](output_11_2.png)
    



    
![png](output_11_3.png)
    



    
![png](output_11_4.png)
    



    
![png](output_11_5.png)
    



    
![png](output_11_6.png)
    



    
![png](output_11_7.png)
    



    
![png](output_11_8.png)
    



    
![png](output_11_9.png)
    



    
![png](output_11_10.png)
    



    
![png](output_11_11.png)
    



```python
from sklearn.preprocessing import LabelEncoder
lable_encoder = LabelEncoder()
for column in dataset.columns.tolist():
    if dataset[column].dtype != 'int64':
        dataset[column] = lable_encoder.fit_transform(dataset[column])
dataset.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>furnishingstatus</th>
      <th>area</th>
      <th>bedrooms</th>
      <th>bathrooms</th>
      <th>stories</th>
      <th>mainroad</th>
      <th>guestroom</th>
      <th>basement</th>
      <th>hotwaterheating</th>
      <th>airconditioning</th>
      <th>parking</th>
      <th>prefarea</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>7420</td>
      <td>4</td>
      <td>2</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>13300000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>8960</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
      <td>12250000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>9960</td>
      <td>3</td>
      <td>2</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>12250000</td>
    </tr>
  </tbody>
</table>
</div>




```python
X = dataset.drop("price", axis=1)
y = dataset["price"]
```


```python
X = sm.add_constant(dataset[['area', 'bedrooms', 'bathrooms', 'stories', 'mainroad', 'guestroom', 'basement', 'hotwaterheating', 'airconditioning', 'parking', 'prefarea']])
X.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>const</th>
      <th>area</th>
      <th>bedrooms</th>
      <th>bathrooms</th>
      <th>stories</th>
      <th>mainroad</th>
      <th>guestroom</th>
      <th>basement</th>
      <th>hotwaterheating</th>
      <th>airconditioning</th>
      <th>parking</th>
      <th>prefarea</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>7420</td>
      <td>4</td>
      <td>2</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1.0</td>
      <td>8960</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1.0</td>
      <td>9960</td>
      <td>3</td>
      <td>2</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>



## Multilple Linear Regression Model


```python
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
```


```python

model = sm.OLS(y_train, X_train).fit()
Y_pred = model.predict(X_test)
print(model.summary())

```

                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:                  price   R-squared:                       0.678
    Model:                            OLS   Adj. R-squared:                  0.670
    Method:                 Least Squares   F-statistic:                     81.21
    Date:                Wed, 14 Feb 2024   Prob (F-statistic):           4.48e-97
    Time:                        17:56:40   Log-Likelihood:                -6640.6
    No. Observations:                 436   AIC:                         1.331e+04
    Df Residuals:                     424   BIC:                         1.335e+04
    Df Model:                          11                                         
    Covariance Type:            nonrobust                                         
    ===================================================================================
                          coef    std err          t      P>|t|      [0.025      0.975]
    -----------------------------------------------------------------------------------
    const           -7.243e+04   2.47e+05     -0.293      0.770   -5.59e+05    4.14e+05
    area              237.7105     25.144      9.454      0.000     188.288     287.133
    bedrooms         7.848e+04   7.61e+04      1.031      0.303   -7.11e+04    2.28e+05
    bathrooms        1.109e+06   1.15e+05      9.608      0.000    8.82e+05    1.34e+06
    stories          4.269e+05   6.92e+04      6.170      0.000    2.91e+05    5.63e+05
    mainroad         4.127e+05    1.5e+05      2.750      0.006    1.18e+05    7.08e+05
    guestroom        2.436e+05   1.42e+05      1.716      0.087   -3.54e+04    5.23e+05
    basement          4.35e+05   1.18e+05      3.690      0.000    2.03e+05    6.67e+05
    hotwaterheating  7.123e+05   2.25e+05      3.165      0.002     2.7e+05    1.15e+06
    airconditioning  8.084e+05   1.18e+05      6.876      0.000    5.77e+05    1.04e+06
    parking          2.474e+05    6.2e+04      3.990      0.000    1.26e+05    3.69e+05
    prefarea         6.368e+05   1.22e+05      5.211      0.000    3.97e+05    8.77e+05
    ==============================================================================
    Omnibus:                       72.064   Durbin-Watson:                   1.893
    Prob(Omnibus):                  0.000   Jarque-Bera (JB):              187.623
    Skew:                           0.810   Prob(JB):                     1.81e-41
    Kurtosis:                       5.775   Cond. No.                     3.05e+04
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
    [2] The condition number is large, 3.05e+04. This might indicate that there are
    strong multicollinearity or other numerical problems.



```python
from sklearn import metrics 
print('Mean Absolute Error:', metrics.mean_absolute_error(y_test, Y_pred))
print('Mean Squared Error:', metrics.mean_squared_error(y_test, Y_pred))
print('Root Mean Squared Error:', np.sqrt(metrics.mean_squared_error(y_test, Y_pred)))


```

    Mean Absolute Error: 979112.2162187381
    Mean Squared Error: 1800793719718.9749
    Root Mean Squared Error: 1341936.5557726545



```python
model0_rsquared = model.rsquared
model0_rsquared_adj = model.rsquared_adj
model0_pvalues = model.pvalues
model0_MSE = metrics.mean_squared_error(y_test, Y_pred)
```

#     Backward Elimination

Before implementing backward elimination I am going to iterate over the X dataset and drop each column and see if the r_sqrd or r_sqrd_Adj increases. If it does, I will flag the column as non significant. If there is no flagged column at the end of the for loop then that means we can't drop any of the columns to continue with backward elimination. 


```python
X.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>const</th>
      <th>area</th>
      <th>bedrooms</th>
      <th>bathrooms</th>
      <th>stories</th>
      <th>mainroad</th>
      <th>guestroom</th>
      <th>basement</th>
      <th>hotwaterheating</th>
      <th>airconditioning</th>
      <th>parking</th>
      <th>prefarea</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>7420</td>
      <td>4</td>
      <td>2</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1.0</td>
      <td>8960</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1.0</td>
      <td>9960</td>
      <td>3</td>
      <td>2</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python

for column in X.columns.tolist():

    if column == 'const':
        continue
    new_X = X.drop(column, axis=1)
    new_X_train, new_X_test, new_y_train, new_y_test = train_test_split(new_X, y, test_size=0.2, random_state=0)
    model2 = sm.OLS(new_y_train, new_X_train).fit()
    new_Y_pred = model2.predict(new_X_test)
    model2_MSE = metrics.mean_squared_error(new_y_test, new_Y_pred)
    pvalues = model.pvalues.to_dict()
    
   
    
    if model2.rsquared_adj > model0_rsquared_adj:
        print(f"Column {column} is significant evaluating based on rsquared_adj")
       
    if model2.rsquared > model0_rsquared:
        print(f"Column {column} is significant evaluating based on rsquared")
        
    if model2_MSE < model0_MSE:
        print(f"Column {column} is not significant evaluating based on MSE")
        
    
    new_X = None
    
```

    Column area is not significant evaluating based on MSE
    Column bedrooms is not significant evaluating based on MSE
    Column bathrooms is not significant evaluating based on MSE
    Column stories is not significant evaluating based on MSE
    Column mainroad is not significant evaluating based on MSE
    Column guestroom is not significant evaluating based on MSE
    Column basement is not significant evaluating based on MSE
    Column hotwaterheating is not significant evaluating based on MSE
    Column airconditioning is not significant evaluating based on MSE
    Column parking is not significant evaluating based on MSE
    Column prefarea is not significant evaluating based on MSE


Based on the results above we can't drop any of the columns based on R-squared values because dropping any of them does not improve our R-squared values, however evaluating based on the MSE, all the columns are candidates for backward elimination. In the next section I am going to be dropping columns based on the MSE recursively until the model with least MSE is achieved.


### Based on the Mean Squared Error


```python

"""
Helper function to conduct backward elimination. It recursively drops the column with the highest pvalue
until the least possible MSE is achieved. 
"""

def backwardElimination(df, column, MSE):
    
    new_X = df.drop(column, axis=1)
    new_X_train, new_X_test, new_y_train, new_y_test = train_test_split(new_X, y, test_size=0.2, random_state=0)
    model2 = sm.OLS(new_y_train, new_X_train).fit()
    new_Y_pred = model2.predict(new_X_test)
    model2_MSE = metrics.mean_squared_error(new_y_test, new_Y_pred)
    
    #getting the model pvalues and indexing them according their corresponding column 
    pvalues = model.pvalues.to_dict()
    columns = list(pvalues.keys())
    column_pvalues = list(pvalues.values())
    largest_pvalue_column = columns[column_pvalues.index(max(column_pvalues))] # get the column with highest pvalue
    
    #Base case for the recursion
    if not len(df.columns.tolist()) == 1:
        return new_X, model2_MS, largest_pvalue_column, model2
    
    #recursive step 
    elif model2_MSE < MSE:
        backwardElimination(new_X, largest_pvalue_column, MSE)
    
    else:
        
        return new_X, model2_MS, largest_pvalue_column, model2
    
prevMSE = model0_MSE

"""
This loop iterates over each column/attribute and calls Backward elimination which drops the column 
and evaluates the MSE and recursively drops column with the highest p_value until the least MSE is achieved. 
"""
for column in X.columns.tolist():

    if column == 'const':
        continue
    
    new_X, mean_squared_error, largest_pvalue_column, model = backwardElimination(X, column, model0_MSE)
    

    if mean_squared_error < prevMSE:
        prevMSE = mean_squared_error
        best_model = model 


    
    
print(best_model.summary())
```

                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:                  price   R-squared:                       0.610
    Model:                            OLS   Adj. R-squared:                  0.601
    Method:                 Least Squares   F-statistic:                     66.46
    Date:                Wed, 14 Feb 2024   Prob (F-statistic):           1.61e-80
    Time:                        17:56:40   Log-Likelihood:                -6718.9
    No. Observations:                 436   AIC:                         1.346e+04
    Df Residuals:                     425   BIC:                         1.350e+04
    Df Model:                          10                                         
    Covariance Type:            nonrobust                                         
    ===================================================================================
                          coef    std err          t      P>|t|      [0.025      0.975]
    -----------------------------------------------------------------------------------
    const            2.918e+05   2.89e+05      1.008      0.314   -2.77e+05    8.61e+05
    bedrooms         2.126e+05    9.1e+04      2.338      0.020    3.39e+04    3.91e+05
    bathrooms        1.103e+06   1.32e+05      8.336      0.000    8.43e+05    1.36e+06
    stories          3.884e+05   7.97e+04      4.874      0.000    2.32e+05    5.45e+05
    mainroad          7.54e+05   1.79e+05      4.221      0.000    4.03e+05    1.11e+06
    guestroom        5.707e+05   1.66e+05      3.435      0.001    2.44e+05    8.97e+05
    basement         2.326e+05   1.42e+05      1.641      0.102    -4.6e+04    5.11e+05
    hotwaterheating  1.138e+06   3.09e+05      3.688      0.000    5.31e+05    1.74e+06
    airconditioning  1.059e+06   1.34e+05      7.914      0.000    7.96e+05    1.32e+06
    parking          3.965e+05   7.07e+04      5.609      0.000    2.58e+05    5.35e+05
    prefarea          9.77e+05   1.43e+05      6.849      0.000    6.97e+05    1.26e+06
    ==============================================================================
    Omnibus:                       84.069   Durbin-Watson:                   2.067
    Prob(Omnibus):                  0.000   Jarque-Bera (JB):              211.754
    Skew:                           0.953   Prob(JB):                     1.04e-46
    Kurtosis:                       5.833   Cond. No.                         22.8
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.


# Conclusion 

Based on my backward elimination which was prioritizing minimizing MSE, I believe this is the best model. Only the area model was dropped which doesn't make too much sense realistically speaking because area of a house should affect its price. I am not sure why the MSE would reduce when we drop the area column however comparing with the first model were all the columns are considered, this final model has a reduced r_squared and adj_rsquared values. Therefore based on those metrics all the columns of the dataset are relevant to house price and should all be factored in model training. 





```python

```
